﻿# Explainable Robotics

神経科学的に妥当なヒューマノイドロボット制御のための説明可能AIフレームワーク